/**
 * test
 *
 * Created by Your Name
 * Copyright (c) 2019 Your Company. All rights reserved.
 */

#import "TiModule.h"

@interface ComBdTestModule : TiModule {

}

@end