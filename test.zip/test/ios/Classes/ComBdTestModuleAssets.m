/**
 * This is a generated file. Do not edit or your changes will be lost
 */
#import "ComBdTestModuleAssets.h"

extern NSData* filterDataInRange(NSData* thedata, NSRange range);

@implementation ComBdTestModuleAssets

- (NSData *)moduleAsset
{
  

  return nil;
}

- (NSData *)resolveModuleAsset:(NSString *)path
{
  

  return nil;
}

@end
